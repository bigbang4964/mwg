MWG Core integration/staging repository
=====================================

### Block Explorer
<a href="https://explorer.frigatechain.com/">https://explorer.frigatechain.com/</a>

### Coin Specs
<table>
<tr><td>Algo</td><td>Quark</td></tr>
<tr><td>Block Time</td><td>60 Seconds</td></tr>
<tr><td>Difficulty Retargeting</td><td>Every Block</td></tr>
<tr><td>Max Coin Supply (PoW Phase)</td><td>57,499,751 MWG</td></tr>
<tr><td>Max Coin Supply (PoS Phase)</td><td>Infinite</td></tr>
<tr><td>Premine</td><td>10,000,001 MWG*</td></tr>
</table>

### Reward Distribution

<table>
<th colspan=4>Genesis Block</th>
<tr><th>Block Height</th><th>Reward Amount</th><th>Notes</th></tr>
<tr><td>1</td><td>10,000,001 MWG</td><td>Initial Pre-mine</td></tr>
</table>

### PoW Rewards Breakdown

<table>
<th>Block Height</th><th>Masternodes</th><th>Miner</th>
<tr><td>2-50000</td><td>50% (125 MWG)</td><td>50% (125 MWG)</td></tr>
<tr><td>50001-150000</td><td>50% (100 MWG)</td><td>50% (100 MWG)</td></tr>
<tr><td>150001-250000</td><td>50% (75 MWG)</td><td>50% (75 MWG)</td></tr>
</table>

### PoS Rewards Breakdown

<table>
<th>Phase</th><th>Block Height</th><th>Reward</th><th>Masternodes & Stakers</th><th>Budget</th>
<tr><td>Phase 0</td><td>250001-300000</td><td>150 MWG</td><td>90% (135 MWG)</td><td>10% (15 MWG)</td></tr>
<tr><td>Phase 1</td><td>300001-350000</td><td>140 MWG</td><td>90% (126 MWG)</td><td>10% (14 MWG)</td></tr>
<tr><td>Phase 2</td><td>350001-400000</td><td>130 MWG</td><td>90% (117 MWG)</td><td>10% (13 MWG)</td></tr>
<tr><td>Phase 3</td><td>400001-450000</td><td>120 MWG</td><td>90% (108 MWG)</td><td>10% (12 MWG)</td></tr>
<tr><td>Phase 4</td><td>450001-500000</td><td>110 MWG</td><td>90% (99 MWG)</td><td>10% (11 MWG)</td></tr>
<tr><td>Phase 5</td><td>500001-550000</td><td>100 MWG</td><td>90% (90 MWG)</td><td>10% (10 MWG)</td></tr>
<tr><td>Phase 6</td><td>550001-600000</td><td>90 MWG</td><td>90% (81 MWG)</td><td>10% (9 MWG)</td></tr>
<tr><td>Phase 7</td><td>600001-650000</td><td>80 MWG</td><td>90% (72 MWG)</td><td>10% (8 MWG)</td></tr>
<tr><td>Phase 8</td><td>650001-700000</td><td>70 MWG</td><td>90% (63 MWG)</td><td>10% (7 MWG)</td></tr>
<tr><td>Phase 9</td><td>700001-750000</td><td>60 MWG</td><td>90% (54 MWG)</td><td>10% (6 MWG)</td></tr>
<tr><td>Phase 10</td><td>750001-800000</td><td>50 MWG</td><td>90% (45 MWG)</td><td>10% (5 MWG)</td></tr>
<tr><td>Phase 11</td><td>800001-850000</td><td>40 MWG</td><td>90% (36 MWG)</td><td>10% (4 MWG)</td></tr>
<tr><td>Phase 12</td><td>850001-900000</td><td>30 MWG</td><td>90% (27 MWG)</td><td>10% (3 MWG)</td></tr>
<tr><td>Phase 13</td><td>900001-950000</td><td>20 MWG</td><td>90% (18 MWG)</td><td>10% (2 MWG)</td></tr>
<tr><td>Phase X</td><td>950001-∞</td><td>10 MWG</td><td>90% (9 MWG)</td><td>10% (1 MWG)</td></tr>
</table>
